# Averia Serif Libre Extension 
# Version 1.0
# display style
# 2021/11/08
# By khirendra

# source : https://fonts.google.com/specimen/DM+Serif+Display?query=Colophon+Foundry
#        : https://github.com/googlefonts/dm-fonts

# This is a static font extension

tar xf $OMFDIR/AveriaSeriffLibre.xz -C $SYSFONT && {
    ui_print '+ Averia Serif Libre Serif'
    local italic=false; mksty serif.* 7 3
    
    font serif.* AveriaSerifLibre-Light.ttf l 
    font serif.* AveriaSerifLibre-LightItalic.ttf li
    font serif.* AveriaSerifLibre-Regular.ttf r
    font serif.* AveriaSerifLibre-Italic.ttf i
    font serif.* AveriaSerifLibre-BoldItalic.ttf bi
    font serif.* AveriaSerifLibre-Bold.ttf b
    
    ver ASLserf
}

  
	
    