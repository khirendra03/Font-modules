# OMF Fira Code Extension
# 2021/12/19

# Fira Code (monospace)
# wght@300..700
# https://github.com/tonsky/FiraCode

# Instructions:
# 1. Copy the following lines to the config file.

#MONO=false
#ML  = wght 300 
#MR  = wght 400 
#MM  = wght 500 
#MSB = wght 600 
#MB  = wght 700 

# 2. Paste them below (or replace) the existing Monospace font styles.
# 3. Uncomment them.


$MONO && return

MS=FiraCode$X

cp $OMFDIR/$MS $FONTS && {
    ui_print '+ Fira Code'
    local up=$MS it= ups=M fa=$MO italic=false
    fallback; mksty 7 3; fontinst
    MONO=true; ver fira
}
