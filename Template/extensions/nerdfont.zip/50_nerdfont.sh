# OMF Nerd Font Mono Extension
# 2021/12/08

# Nerd Font icons
# https://github.com/ryanoasis/nerd-fonts


tar xf $OMFDIR/nerdfont.xz -C $SYSFONT && {
    ui_print '  Nerd Font Mono'
    ver nf
}
