# OMF JetBrains Mono Extension
# 2023/04/19 | v2.304

# JetBrains Mono (monospace)
# wght@100..800
# https://www.jetbrains.com/lp/mono/

# Instructions:
# 1. Copy the following lines to the config file.

# MONO=false

# MT  = wght 100 
# MEL = wght 200 
# ML  = wght 300 
# MR  = wght 400 
# MM  = wght 500 
# MSB = wght 600 
# MB  = wght 700 
# MEB = wght 800 

# 2. Paste them below (or replace) the existing Monospace font styles.
# 3. Uncomment them.


$MONO && return

MS=JetBrainsMono$X
MSI=JetBrainsMono-$It$X

tar xf $OMFDIR/JetBrainsMono.xz -C $FONTS && {
    ui_print '+ JetBrains Mono'
    local up=$MS it=$MSI ups=M fa=$MO
    fallback; mksty 8 1; fontinst
    MONO=true; ver jbm
}
