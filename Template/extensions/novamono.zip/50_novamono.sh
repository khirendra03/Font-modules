# OMF Nova Mono Extension
# 2021/07/31

# Nova Mono (monospace)
# wght@400
# https://fonts.google.com/specimen/Nova+Mono

# Intructions:
# In the config file, set MONO=false


$MONO && return

cp $OMFDIR/$MS $SYSFONT && {
    ui_print '+ Nova Mono'
    fallback; font $MO NovaMono-$Re$X r
    MONO=true; ver nova
}
