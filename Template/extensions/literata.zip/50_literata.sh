# OMF Literata Extension
# 2021/12/21

# Literata (serif)
# wght@200..900 opsz@7..72
# https://fonts.google.com/specimen/Literata

# Instructions:
# 1. Copy the following lines to the config file.

#SERF=false
#SEL = wght 200 opsz 12
#SL  = wght 300 opsz 12
#SR  = wght 400 opsz 12
#SM  = wght 500 opsz 18
#SSB = wght 600 opsz 24
#SB  = wght 700 opsz 24
#SEB = wght 800 opsz 36
#SBL = wght 900 opsz 48

# 2. Paste them below (or replace) the existing Monospace font styles.
# 3. Uncomment them.


$SERF && return

SER=Literata$X
SERI=Literata-Italic$X

tar xf $OMFDIR/Literata.xz -C $FONTS && {
    ui_print '+ Literata'
    local up=$SER it=$SERI ups=S fa=$SE
    fallback; mksty 9 2; fontinst
    SERF=true; ver lit
}
