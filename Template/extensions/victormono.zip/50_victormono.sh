# OMF Victor Mono Extension
# 2021/07/31

# Victor Mono (monospace)
# wght@400,700
# https://rubjo.github.io/victor-mono/

# Instructions:
# In the config file, set MONO=false


$MONO && return

tar xf $OMFDIR/VictorMono.xz -C $SYSFONT && {
    ui_print '+ Victor Mono'
    fallback; mksty $MO 7 4 3
    font $MO VictorMono-$Re$X r
    font $MO VictorMono-$It$X ri
    font $MO VictorMono-$Bo$X b
    font $MO VictorMono-$Bo$It$X bi
    MONO=true; ver victor
}
