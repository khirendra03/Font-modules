# OMF TWRP Extension
# 2021/11/22


$BOOTMODE || {
    BACKUP=`find $ORIPRDFONT $ORIPRDETC $ORISYSFONT $ORISYSETC $ORISYSEXTETC -type f -name '*~'`
    [ -f $OMFDIR/twrp -a -f $OMFDIR/coreutils -a -f $OMFDIR/module.prop -a -n "$BACKUP" ] && {
        ui_print '- Uninstalling'
        for i in $BACKUP; do mv $i ${i%?}; done
        rm $OMFDIR/module.prop
        recovery_cleanup
        rm -rf $TMPDIR
        ui_print '- Done'
        exit 0
    }
}
