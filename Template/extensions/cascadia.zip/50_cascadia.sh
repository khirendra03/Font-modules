# OMF Cascadia Code Extenstion
# 2021/12/19

# Cascadia Code (monospace)
# wght@200..700
# https://github.com/microsoft/cascadia-code

# Instructions:
# 1. Copy the following lines to the config file.

#MONO=false
#MEL = wght 200 
#ML  = wght 300 
#MR  = wght 400 
#MM  = wght 500 
#MSB = wght 600 
#MB  = wght 700 

# 2. Paste them below (or replace) the existing Monospace font styles.
# 3. Uncomment them.


$MONO && return

MS=CascadiaCodePL$X
MSI=CascadiaCodePL$It$X

tar xf $OMFDIR/Cascadia.xz -C $FONTS && {
    ui_print '+ Cascadia Code'
    local up=$MS it=$MSI ups=M fa=$MO
    fallback; mksty 7 2; fontinst
    MONO=true; ver cas
}
