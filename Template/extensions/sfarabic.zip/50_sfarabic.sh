# OMF SFArabic Extension
# 2023/01/15

# SF Arabic
# wght@1..1000 opsz@17..80

# Instructions:
# 1. Copy the following lines to the config file.

#AT  = opsz OPSZ wght 1
#AEL = opsz OPSZ wght 101
#AL  = opsz OPSZ wght 267
#AR  = opsz OPSZ wght 400
#AM  = opsz OPSZ wght 511
#ASB = opsz OPSZ wght 622
#AB  = opsz OPSZ wght 711
#AEB = opsz OPSZ wght 844
#ABL = opsz OPSZ wght 1000

# 2. Uncomment them.

local noto=NotoNaskhArabic-$Re$X sfa=SFArabic$X
tar xf $OMFDIR/sfarabic.xz -C $FONTS || abort
ui_print "+ SF Arabic"
$ROUNDED && sfa=SFArabicRounded$X && ui_print "  Rounded"
mv $FONTS/$sfa $FONTS/$noto
local up=$noto ups=A italic=false fa; getsty
for fa in und-Arab.*elegant ug.*elegant und-Arab.*compact ug.*compact; do
    mkstya; fontinst
done
