# OMF Iosevka Extension
# 2022/08/01

# Iosevka (monospace)
# wght@400,700
# https://github.com/be5invis/Iosevka

# Instructions:
# In the config file, set MONO = false


$MONO && return

tar xf $OMFDIR/Iosevka.xz -C $FONTS && {
    ui_print '  Iosevka'
    local fa=$MO up=Iosevka-
    fba; mkstya; fontinst
    MONO=true; ver iosevka
}
