# Source Sherif Pro VF (serif) Extension
# 2021/09/09

# Source Sherif Pro VF
# wght@200..900
# opsz@8..60

# source
# https://github.com/adobe-fonts/source-serif
#


# In the config file, set SERF=false
# and if SERF line is not their then add it
# and Serif font styles as below:
#

# SEL = wght 200 opsz
# SL  = wght 300 opsz
# SR  = wght 400 opsz
# SM  = wght 500 opsz
# SSB = wght 600 opsz
# SB  = wght 700 opsz
# SEB = wght 800 opsz
# SBL = wght 900 opsz

${SERF:=`valof SERF`} && return

[ "$SEL" ] || SEL='wght 200 opsz 16.0'
[ "$SL" ] || SL='wght 300 ops, 16.0'
[ "$SR" ] || SR='wght 400 opsz 16.0'
[ "$SM" ] || SM='wght 500 opsz 20.0'
[ "$SSB" ] || SSB='wght 600 opsz 20.0'
[ "$SB" ] || SB='wght 700 opsz 20.0'
[ "$SEB" ] || SEB='wght 800 ops, 20.0'
[ "$SBL" ] || SBL='wght 900 opsz 20.0'

SER=SourceSerif-VF-Roman.ttf
SERI=SourceSerif-VF-Italic.ttf

cp $OMFDIR/$SER $OMFDIR/$SERI $SYSFONT && {
    ui_print '+ Source Serif Pro VF'
    mksty $SE 9 2
    for i in $FW; do
        eval $(echo font $SE $SER $i \$S`up $i`)
        eval $(echo font $SE $SERI ${i}i \$S`up $i`)
    done
    ver SSrf
    SERF=true 
}


### other styls for optical axis ###
#
# caption : opsz 8.0
# smtext  : opsz 16.0
# Regular : opsz 20.0
# subhend : opsz 32.0
# display : opsz 60.0