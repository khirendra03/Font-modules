# Source Code Pro (Mono) Extension
# 2021/09/09                                   

# Source Code Pro (monospace)
# wgth@200..900
# https://github.com/adobe-fonts/source-code-pro


# In the config file, set MONO=false 
# if MONO line is not their then add it
# and Monospace font styles as below:
#
# MEL = wght 200 
# ML  = wght 300 
# MR  = wght 400 
# MM  = wght 500
# MSB = wght 600 
# MB  = wght 700 
# MEB = wght 800 
# MBL = wght 900 


${MONO:=`valof MONO`} && return

[ $MEL ] || MEL='wght 200'
[ $ML ] || ML='wght 300'
[ $MR ] || MR='wght 400'
[ $MM ] || MM='wght 500'
[ $MSB ] || MSB='wght 600'
[ $MB ] || MB='wght 700'
[ $MEB ] || MEB='wght 800'
[ $MBL ] || MBL='wght 900'

MS=SourceCodeVariable-Roman.ttf
MSI=SourceCodeVariable-Italic.ttf

cp $OMFDIR/$MS $OMFDIR/$MSI $SYSFONT && {
    ui_print '+ Source Code Pro (Mono) VF'
    local italic=false; mksty $MO 9 2 
    for i in el l r m sb b eb bl; do
        eval $(echo font $MO $MS $i \$M`up $i`)
        eval $(echo font $SE $MSI ${i}i \$S`up $i`)
    done
    MONO=true; ver SCode
}                                

