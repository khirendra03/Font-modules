# Space Mono Extension 
# Version 1.0
# 2021/09/17
# By khirendra

# source : https://github.com/googlefonts/spacemono
#        : https://fonts.google.com/specimen/Space+Mono

# This is a static font extension

cp $OMFDIR/SpaceMono/*ttf $SYSFONT && {
    ui_print '+ Space Mono'
    local italic=false; mksty monospace.* 7 4
    font monospace.* SpaceMono-Regular.ttf r
    font monospace.* SpaceMono-Italic.ttf i
    font monospace.* SpaceMono-Bold.ttf b
    font monospace.* SpaceMono-BoldItalic.ttf bi
    ver SpaceM
}

    