# DM (DeepMind) Mono Extension 
# Version 1.0
# 2021/10/11
# By khirendra

# source : https://github.com/googlefonts/dm-mono
#        : https://fonts.google.com/specimen/DM+Mono?query=Colophon+Foundry

# This is a static font extension

cp $OMFDIR/DM_Mono/*ttf $SYSFONT && {
    ui_print '+ DM (DeepMind) Mono'
    local italic=false; mksty monospace.* 7 1
    font monospace.* DMMono-Light.ttf l
    font monospace.* DMMono-LightItalic.ttf li
    font monospace.* DMMono-Regular.ttf r
    font monospace.* DMMono-Italic.ttf i
    font monospace.* DMMono-Medium.ttf m
    font monospace.* DMMono-MediumItalic.ttf mi
    ver DMmono
}

    #font monospace.* DMMono-VF7.ttf l wght 300
    #font monospace.* DMMono-VF7.ttf r wght 400
    #font monospace.* DMMono-VF7.ttf m wght 500
    #font monospace.* DMMono-VF7.ttf sb wght 600
    #font monospace.* DMMono-VF7.ttf b wght 700
	
	
    