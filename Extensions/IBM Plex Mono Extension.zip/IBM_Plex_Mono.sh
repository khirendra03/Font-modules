# IBM Plex Mono Extension 
# Version 2.0
# 2021/08/30
# By khirendra

# source : https://www.ibm.com/plex/
#        : https://fonts.google.com/?query=ibm+plex

# This is a static font extension

cp $OMFDIR/IBM_Plex_Mono/*ttf $SYSFONT && {
    ui_print '+ IBM Plex Mono'
    local italic=false; mksty monospace.* 7 1
    font monospace.* IBMPlexMono-ExtraLight.ttf el
    font monospace.* IBMPlexMono-ExtraLightItalic.ttf eli
    font monospace.* IBMPlexMono-Light.ttf l
    font monospace.* IBMPlexMono-LightItalic.ttf li
    font monospace.* IBMPlexMono-Thin.ttf t
    font monospace.* IBMPlexMono-ThinItalic.ttf ti
    font monospace.* IBMPlexMono-Regular.ttf r
    font monospace.* IBMPlexMono-Italic.ttf i
    font monospace.* IBMPlexMono-Medium.ttf m
    font monospace.* IBMPlexMono-MediumItalic.ttf mi
    font monospace.* IBMPlexMono-SemiBold.ttf sb
    font monospace.* IBMPlexMono-SemiBoldItalic.ttf sbi
    font monospace.* IBMPlexMono-Bold.ttf b
    font monospace.* IBMPlexMono-BoldItalic.ttf bi
    ver IBMPmono
}

    #font monospace.* IBMPlexMono-VF7.ttf l wght 300
    #font monospace.* IBMPlexMono-VF7.ttf r wght 400
    #font monospace.* IBMPlexMono-VF7.ttf m wght 500
    #font monospace.* IBMPlexMono-VF7.ttf sb wght 600
    #font monospace.* IBMPlexMono-VF7.ttf b wght 700
	
	
    