# IBM Plex Sans Devnagri Extension 
# Version 2.0
# 2021/08/30
# By khirendra

# source : https://www.ibm.com/plex/
#        : https://fonts.google.com/?query=ibm+plex
# This is a static font extension

cp $OMFDIR/IBM_Plex_Sans_Devanagari/*ttf $SYSFONT && {
    ui_print '+ IBM Plex Sans Devanagari'
    local italic=false; mksty und-Deva.* 7 2
    font und-Deva.* IBMPlexSansDevanagari-ExtraLight.ttf el
    font und-Deva.* IBMPlexSansDevanagari-Light.ttf l
    font und-Deva.* IBMPlexSansDevanagari-Thin.ttf t
    font und-Deva.* IBMPlexSansDevanagari-Regular.ttf r
    font und-Deva.* IBMPlexSansDevanagari-Medium.ttf m
    font und-Deva.* IBMPlexSansDevanagari-SemiBold.ttf sb
    font und-Deva.* IBMPlexSansDevanagari-Bold.ttf b
    ver IBMPdeva
}

    #font und-Deva.* IBMPlexSansDevanagari-VF7.ttf l wght 300
    #font und-Deva.* IBMPlexSansDevanagari-VF7.ttf r wght 400
    #font und-Deva.* IBMPlexSansDevanagari-VF7.ttf m wght 500
    #font und-Deva.* IBMPlexSansDevanagari-VF7.ttf sb wght 600
    #font und-Deva.* IBMPlexSansDevanagari-VF7.ttf b wght 700
	
	
    