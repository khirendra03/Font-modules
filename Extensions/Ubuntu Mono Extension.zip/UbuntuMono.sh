# Ubuntu Mono Extension 
# Version 1.0
# 2021/09/13
# By khirendra

# source : https://github.com/daltonmaag/ubuntu
#        : https://fonts.google.com/specimen/Ubuntu+Mono?query=Dalton+Maag

# This is a static font extension

# In the config file, set MONO=false

cp $OMFDIR/Ubantu_Mono/*ttf $SYSFONT && {
    ui_print '+ Ubuntu Mono font'
    local italic=true; mksty monospace.* 7 4
    font monospace.* UbuntuMono-Regular.ttf r
    font monospace.* UbuntuMono-Italic.ttf i
    font monospace.* UbuntuMono-Bold.ttf b
    font monospace.* UbuntuMono-BoldItalic.ttf bi
    ver Ubmono
}


    #font monospace.* font_name-VF7.ttf l wght 300
    #font monospace.* font_name-VF7.ttf r wght 400
    #font monospace.* font_name-VF7.ttf m wght 500
    #font monospace.* font_name-VF7.ttf sb wght 600
    #font monospace.* font_name-VF7.ttf b wght 700
	
	
    
  