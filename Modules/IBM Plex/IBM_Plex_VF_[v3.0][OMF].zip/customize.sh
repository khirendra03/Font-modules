. $MODPATH/ohmyfont.sh

### INSTALLATION ###

ui_print '- Installing'

ui_print '+ Prepare'
prep

ui_print '+ Configure'
config

ui_print '+ IBM Plex Font'
install_font

src

ui_print '+ Rom'
rom
fontspoof
finish
