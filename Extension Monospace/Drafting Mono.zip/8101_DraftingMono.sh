# Drafting* Mono VF Extension
# 2021/10/20

# Drafting Mono Variable font
# wght@400..700
# https://github.com/indestructible-type/Drafting

# In the config file, set MONO=false
# and Mono font styles as below:
#


# MR  = wght 400 
# MM  = wght 500 
# MSB = wght 600 
# MB  = wght 700 


${MONO:=`valof MONO`} && return

[ $MR ] || MR='wght 400'
[ $MM ] || MM='wght 500'
[ $MSB ] || MSB='wght 600'
[ $MB ] || MB='wght 700'


MS=Drafting.ttf
MSI=Drafting-Italic.ttf

tar xf $OMFDIR/Drafting.xz -C $SYSFONT && {
    ui_print '+ Drafting* Mono VF'
    mksty $MO 7 4
    for i in r m sb b; do
        eval $(echo font $MO $MS $i \$M`up $i`)
        eval $(echo font $SE $MSI ${i}i \$S`up $i`)
    done
    ver Draft
    MONO=true 
}
