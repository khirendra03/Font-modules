# josefin Slab VF (Slab serif) Extension
# 2021/08/14

# Josefin Slab VF (Slab Serif)
# wght@100..700
# https://fonts.google.com/specimen/Josefin+Sans

# In the config file, set SERF=false
# and Serif font styles as below:
#

# ST  = wght 100
# SUL  = wght 200
# SL = wght 300
# SR  = wght 400 
# SM  = wght 500 
# SSB = wght 600 
# SB  = wght 700 


${SERF:=`valof SERF`} && return

[ "$ST" ] || ST='wght 100'
[ "$SUL" ] || SUL='wght 200'
[ "$SL" ] || SL='wght 300'
[ "$SR" ] || SR='wght 400'
[ "$SM" ] || SM='wght 500'
[ "$SSB" ] || SSB='wght 600'
[ "$SB" ] || SB='wght 700'


SER=JosefinSlab-VF.ttf
SERI=JosefinSlab-Italic-VF.ttf

cp $OMFDIR/$SER $OMFDIR/$SERI $SYSFONT && {
    ui_print '+ Josefin Slab VF'
    mksty $SE 7 1
    for i in $FW; do
        eval $(echo font $SE $SER $i \$S`up $i`)
        eval $(echo font $SE $SERI ${i}i \$S`up $i`)
    done
    ver jsslsf
    SERF=true 
}
