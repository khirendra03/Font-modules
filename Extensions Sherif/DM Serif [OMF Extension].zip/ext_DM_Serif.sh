# DM (DeepMind) Serif Extension 
# Version 1.0
# display style
# 2021/10/11
# By khirendra

# source : https://fonts.google.com/specimen/DM+Serif+Display?query=Colophon+Foundry
#        : https://github.com/googlefonts/dm-fonts

# This is a static font extension

cp $OMFDIR/DM_Serif/*ttf $SYSFONT && {
    ui_print '+ DM (DeepMind Display) Serif'
    local italic=false; mksty serif.* 7 1
    font serif.* DeepMindSerifDisplay-Regular.ttf r
    font serif.* DeepMindSerifDisplay-Italic.ttf i
    ver DMserf
}

    #font serif.* DeepMindSerifDisplay-VF7.ttf l wght 300
    #font serif.* DeepMindSerifDisplay-VF7.ttf r wght 400
    #font serif.* DeepMindSerifDisplay-VF7.ttf m wght 500
    #font serif.* DeepMindSerifDisplay-VF7.ttf sb wght 600
    #font serif.* DeepMindSerifDisplay-VF7.ttf b wght 700
	
	
    