# Vollkorn VF (serif) Extension
# 2021/07/30

# Vollkorn VF (Serif)
# wght@400..900
# https://github.com/FAlthausen/Vollkorn-Typeface
# https://fonts.google.com/specimen/Vollkorn

# In the config file, set SERF=false
# and Serif font styles as below:
#

# SR  = wght 400 
# SM  = wght 500 
# SSB = wght 600 
# SB  = wght 700 
# SEB = wght 800
# SBL = wght 900

${SERF:=`valof SERF`} && return

[ "$SR" ] || SR='wght 400'
[ "$SM" ] || SM='wght 500'
[ "$SSB" ] || SSB='wght 600'
[ "$SB" ] || SB='wght 700'
[ "$SEB" ] || SEB='wght 800'
[ "$SBL" ] || SBL='wght 900'

SER=Vollkorn-VF.ttf
SERI=Vollkorn-Italic-VF.ttf

cp $OMFDIR/$SER $OMFDIR/$SERI $SYSFONT && {
    ui_print '+ Vollkorn Serif VF'
    mksty $SE 9 4
    for i in $FW; do
        eval $(echo font $SE $SER $i \$S`up $i`)
        eval $(echo font $SE $SERI ${i}i \$S`up $i`)
    done
    ver volksf
    SERF=true 
}
