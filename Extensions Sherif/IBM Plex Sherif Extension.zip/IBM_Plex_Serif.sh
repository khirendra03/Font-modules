# IBM Plex Serif Extension 
# Version 2.0
# 2021/08/30
# By khirendra

# source : https://www.ibm.com/plex/
#        : https://fonts.google.com/?query=ibm+plex

# This is a static font extension

cp $OMFDIR/IBM_Plex_Serif/*ttf $SYSFONT && {
    ui_print '+ IBM Plex Serif'
    local italic=false; mksty serif.* 7 1
    font serif.* IBMPlexSerif-ExtraLight.ttf el
    font serif.* IBMPlexSerif-ExtraLightItalic.ttf eli
    font serif.* IBMPlexSerif-Light.ttf l
    font serif.* IBMPlexSerif-LightItalic.ttf li
    font serif.* IBMPlexSerif-Thin.ttf t
    font serif.* IBMPlexSerif-ThinItalic.ttf ti
    font serif.* IBMPlexSerif-Regular.ttf r
    font serif.* IBMPlexSerif-Italic.ttf i
    font serif.* IBMPlexSerif-Medium.ttf m
    font serif.* IBMPlexSerif-MediumItalic.ttf mi
    font serif.* IBMPlexSerif-SemiBold.ttf sb
    font serif.* IBMPlexSerif-SemiBoldItalic.ttf sbi
    font serif.* IBMPlexSerif-Bold.ttf b
    font serif.* IBMPlexSerif-BoldItalic.ttf bi
    ver IBMPser
}

    #font serif.* IBMPlexSerif-VF7.ttf l wght 300
    #font serif.* IBMPlexSerif-VF7.ttf r wght 400
    #font serif.* IBMPlexSerif-VF7.ttf m wght 500
    #font serif.* IBMPlexSerif-VF7.ttf sb wght 600
    #font serif.* IBMPlexSerif-VF7.ttf b wght 700
	
	
    