# ios emoji 14.0 Extension 
# by khirendra
#credit: @nongthaihoang, @MrCarb0n and MFFM @telegram
# 2021/08/03

# Style: ios, Unicode 13

cp $OMFDIR/ios_emoji.ttf $SYSFONT/NotoColorEmoji.ttf && {
    ui_print '+ iOS emoji 14.0 '
    if [ -f $ORISYSFONT/SamsungColorEmoji.ttf ]; then
    mv $SYSFONT/NotoColorEmoji.ttf $SYSFONT/SamsungColorEmoji.ttf;
    fi
    ver iemoji
}
