# TMNT emoji
# by @khirendra
# 2021/09/16

# Style: ios, TMNT

    cp $OMFDIR/TMNT.ttf $SYSFONT/NotoColorEmoji.ttf && {
    ui_print '+ TMNT emoji'
    if [ -f $ORISYSFONT/SamsungColorEmoji.ttf ]; then
    mv $SYSFONT/NotoColorEmoji.ttf $SYSFONT/SamsungColorEmoji.ttf;
    fi
    ver Temoji
}
